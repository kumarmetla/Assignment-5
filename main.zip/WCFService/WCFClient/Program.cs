﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WCFClient.ServiceReference1;

namespace WCFClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Service1Client myclient = new Service1Client();
            
            int a, b;
            //a = 30;
            Console.WriteLine("enter a value");
            a = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("enter b value");
            b = Convert.ToInt16(Console.ReadLine());
           // b = 40;
            Console.WriteLine(myclient.myData(a, b));
            Console.WriteLine("enter x value");
            double x=Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(myclient.myOpp(x));
            Console.WriteLine(myclient.WelcomeMessage("Kumar from Sandisk"));
            Console.ReadLine();
        }
    }
}
