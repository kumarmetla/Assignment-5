﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;

namespace SampleCode
{
    public class Sample:IPlugin
    {
        
        #region [execute]
        public void Execute(IServiceProvider _serviceProvider)
        {

            
                IPluginExecutionContext context = (IPluginExecutionContext)_serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)_serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService _service = serviceFactory.CreateOrganizationService(context.UserId); ;
                ITracingService track = (ITracingService)_serviceProvider.GetService(typeof(ITracingService));
                if(context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entity = (Entity)context.InputParameters["Target"];
                    if(entity.LogicalName=="account" && context.MessageName=="Create")
                    {
                        try
                        {

                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }

                    }
                }

          
        }
        #endregion
    

    }
}
